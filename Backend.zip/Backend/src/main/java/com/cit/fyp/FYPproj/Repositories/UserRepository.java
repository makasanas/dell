package com.cit.fyp.FYPproj.Repositories;

import com.cit.fyp.FYPproj.Entities.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}

