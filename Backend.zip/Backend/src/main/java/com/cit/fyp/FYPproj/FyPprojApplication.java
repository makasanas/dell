package com.cit.fyp.FYPproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FyPprojApplication {


	public static void main(String[] args) {
		SpringApplication.run(FyPprojApplication.class, args);
	}

}
