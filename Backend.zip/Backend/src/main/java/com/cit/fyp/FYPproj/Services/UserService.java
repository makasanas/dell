package com.cit.fyp.FYPproj.Services;

import java.util.List;
import com.cit.fyp.FYPproj.Entities.User;
import com.cit.fyp.FYPproj.Entities.UserRequest;


public interface UserService {
  void resetCredentials();

  User findById(Long id);

  User findByUsername(String username);

  List<User> findAll();

  User save(UserRequest user);
}
