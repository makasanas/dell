package com.cit.fyp.FYPproj.Repositories;

import com.cit.fyp.FYPproj.Entities.Authority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorityRepository extends JpaRepository<Authority, Long> {
  Authority findByName(String name);
}
